from django.contrib import admin
from django.contrib import admin
from .models import ChargeHistory

admin.site.register(ChargeHistory)
# Register your models here.
