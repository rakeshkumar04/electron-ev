from django.apps import AppConfig


class ChargeHistoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'charge_history'
